#!/usr/bin/env python3
"""Adapte le projet Android généré par `npx cap add android` :
permission caméra, orientation portrait, icônes, splash, numéro de version."""
import os, re, shutil, struct, zlib, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
APP = os.path.join(ROOT, "android", "app")
MAIN = os.path.join(APP, "src", "main")
RES = os.path.join(MAIN, "res")
TEAL = "#0F766E"

def read(p):
    with open(p, encoding="utf-8") as f: return f.read()
def write(p, s):
    with open(p, "w", encoding="utf-8") as f: f.write(s)
def must(cond, msg):
    if not cond:
        sys.exit("ERREUR patch_android : " + msg)

# 1) Manifeste : caméra + portrait
mf = os.path.join(MAIN, "AndroidManifest.xml")
s = read(mf)
if "android.permission.CAMERA" not in s:
    s = s.replace('<uses-permission android:name="android.permission.INTERNET" />',
        '<uses-permission android:name="android.permission.INTERNET" />\n'
        '    <uses-permission android:name="android.permission.CAMERA" />\n'
        '    <uses-feature android:name="android.hardware.camera" android:required="false" />\n'
        '    <uses-feature android:name="android.hardware.camera.autofocus" android:required="false" />')
    must("android.permission.CAMERA" in s, "balise INTERNET introuvable dans le manifeste")
if "screenOrientation" not in s:
    s = s.replace('android:name=".MainActivity"', 'android:name=".MainActivity"\n            android:screenOrientation="portrait"')
    must("screenOrientation" in s, "activité MainActivity introuvable")
write(mf, s)

# 2) Couleur d'icône + splash
bg = os.path.join(RES, "values", "ic_launcher_background.xml")
write(bg, '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">%s</color>\n</resources>\n' % TEAL)
st = os.path.join(RES, "values", "styles.xml")
s = read(st)
if "windowSplashScreenBackground" not in s:
    s = s.replace('<item name="android:background">@drawable/splash</item>',
        '<item name="android:background">@drawable/splash</item>\n'
        '        <item name="windowSplashScreenBackground">@color/ic_launcher_background</item>\n'
        '        <item name="windowSplashScreenAnimatedIcon">@mipmap/ic_launcher_foreground</item>')
    must("windowSplashScreenBackground" in s, "thème de lancement introuvable")
write(st, s)

def png1x1(rgb):
    raw = b"\x00" + bytes(rgb)
    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 2, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b""))
teal = png1x1((0x0F, 0x76, 0x6E))
for d in os.listdir(RES):
    if d.startswith("drawable") and os.path.exists(os.path.join(RES, d, "splash.png")):
        with open(os.path.join(RES, d, "splash.png"), "wb") as f: f.write(teal)

# 3) Icônes
src = os.path.join(ROOT, "resources", "android", "res")
if os.path.isdir(src):
    for d in os.listdir(src):
        dst = os.path.join(RES, d); os.makedirs(dst, exist_ok=True)
        for fn in os.listdir(os.path.join(src, d)):
            shutil.copy2(os.path.join(src, d, fn), os.path.join(dst, fn))

# 4) Version
gr = os.path.join(APP, "build.gradle")
s = read(gr)
vn = os.environ.get("VERSION_NAME", "1.0"); vc = os.environ.get("VERSION_CODE", "1")
s = re.sub(r"versionCode\s+\d+", "versionCode " + vc, s)
s = re.sub(r'versionName\s+"[^"]*"', 'versionName "%s"' % vn, s)
write(gr, s)
print("patch_android : OK (versionName=%s, versionCode=%s)" % (vn, vc))
